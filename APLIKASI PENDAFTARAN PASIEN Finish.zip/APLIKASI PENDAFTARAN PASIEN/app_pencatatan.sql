-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Jun 2022 pada 12.02
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app_pencatatan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `berobat`
--

CREATE TABLE `berobat` (
  `id` int(11) NOT NULL,
  `tggl_daftar` date NOT NULL,
  `no_pasien` int(11) NOT NULL,
  `nm_pasien` varchar(255) NOT NULL,
  `no_telp` int(11) NOT NULL,
  `keluhan` varchar(255) NOT NULL,
  `poli` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `berobat`
--

INSERT INTO `berobat` (`id`, `tggl_daftar`, `no_pasien`, `nm_pasien`, `no_telp`, `keluhan`, `poli`) VALUES
(1, '2022-06-02', 1, 'tes', 2312, '', 'tes'),
(2, '2022-06-02', 2, 'Tess', 323, '', 'Tesss'),
(3, '2022-06-02', 2312, 'asdfasd', 23213, 'rtrgerg', 'dffdsf'),
(4, '2022-06-02', 2323, 'afafa', 3242343, 'fafdafad', 'fadffafd');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `Id` int(11) NOT NULL,
  `nm_pasien` varchar(255) NOT NULL,
  `no_identitas` int(10) NOT NULL,
  `tggl_lahir` date NOT NULL,
  `tmpt_lahir` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `no_telp` int(15) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`Id`, `nm_pasien`, `no_identitas`, `tggl_lahir`, `tmpt_lahir`, `alamat`, `no_telp`, `jenis_kelamin`) VALUES
(1, 'tes', 1, '0000-00-00', '2022-06-02', 'a', 0, 'Perempuan'),
(2, 'tes', 1, '0000-00-00', '2022-06-02', 'tes', 123, 'Perempuan'),
(3, 'tes', 1, '2022-06-03', 'tes', 'es', 213, 'Laki-Laki'),
(4, 'tes', 2, '2022-06-03', 'tes', 'es', 213, 'Perempuan'),
(5, 'Tes1', 1212, '2022-06-02', 'tess', 'tessss', 2321312, 'Perempuan'),
(6, 'Tes1', 1212, '2022-06-02', 'tess', 'tessss', 2321312, 'Laki-Laki');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `berobat`
--
ALTER TABLE `berobat`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `no_pasien` (`no_pasien`);

--
-- Indeks untuk tabel `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `berobat`
--
ALTER TABLE `berobat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pasien`
--
ALTER TABLE `pasien`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
