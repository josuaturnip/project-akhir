﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace APLIKASI_PENDAFTARAN_PASIEN
{
    internal class Berobat:Connection
    {
        MySqlConnection conn;
        MySqlCommand cmd;

        public String id { get; set; }
        public String nama_pasien { get; set; }
        public String no_pasien { get; set; }
        public String tggl_daftar { get; set; }
        public String no_telp { get; set; }
        public String keluhan { get; set; }
        public String poli { get; set; }

        public Berobat()
        {
            conn = new MySqlConnection(conString);
            cmd = new MySqlCommand();
        }

        public String Insert()
        {
            String error = null;
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO berobat (id,nm_pasien,no_pasien,tggl_daftar,no_telp,keluhan,poli) " +
                "VALUES (@id,@nm_pasien,@no_pasien,@tggl_daftar,@no_telp,@keluhan,@poli)";
            cmd.Parameters.AddWithValue("@id", this.id);
            cmd.Parameters.AddWithValue("@nm_pasien", this.nama_pasien);
            cmd.Parameters.AddWithValue("@no_pasien", this.no_pasien);
            cmd.Parameters.AddWithValue("@tggl_daftar", this.tggl_daftar);
            cmd.Parameters.AddWithValue("@no_telp", this.no_telp);
            cmd.Parameters.AddWithValue("@keluhan", this.keluhan);
            cmd.Parameters.AddWithValue("@poli", this.poli);
            


            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                error = e.Message;
            }
            return error;
        }
    }
}
