﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APLIKASI_PENDAFTARAN_PASIEN
{
    internal class Connection
    {
        protected String conString = "server = localhost; database = app_pencatatan; uid = root; sslMode = none; password =";
    }
}
