﻿using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;
using System.Drawing.Imaging;
using System.Globalization;

namespace APLIKASI_PENDAFTARAN_PASIEN
{
    public partial class FormBerobat : Form
    {
        ArrayList berobatlist = new ArrayList();
        System.Collections.ArrayList DaftarBerobat = new ArrayList();
        public FormBerobat()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        public void clear()
        {
            textBoxNama.Text = "";
            textBoxNoPasien.Text = "";
            textBoxKeluhan.Text = "";
            textBoxPoli.Text = "";
            textBoxId.Text = "";
            dateTimePickerTggl.Value = DateTime.Now;
            textBoxTelp.Text = "";
 
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Berobat berobat = new Berobat();
            berobat.id = textBoxId.Text;
            berobat.nama_pasien = textBoxNama.Text;
            berobat.no_pasien = textBoxNoPasien.Text;
            berobat.tggl_daftar = dateTimePickerTggl.Value.ToString("yyyy-MM-dd");
            berobat.no_telp = textBoxTelp.Text;
            berobat.keluhan = textBoxKeluhan.Text;
            berobat.poli = textBoxPoli.Text;

            DaftarBerobat.Add(berobat);



            String response;
            response = berobat.Insert();
            if (response == null)
            {

                MessageBox.Show("Insert Data Berhasil");
                clear();

            }
            else if (response != null)
                MessageBox.Show("Insert Data Gagal " + response);
        }
    }
}
