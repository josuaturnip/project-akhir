﻿using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;
using System.Drawing.Imaging;
using System.Globalization;


namespace APLIKASI_PENDAFTARAN_PASIEN
{
    public partial class FormTable : Form
    {

        public FormTable()
        {
            InitializeComponent();
        }
        

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            FormBerobat frmberobat = new FormBerobat();
            frmberobat.Show();
            this.Close();
        }

        public void display_data_pasien()
        {
            MySqlConnection conn = new MySqlConnection("server = localhost; database = app_pencatatan; uid = root; sslMode = none; password = ; convert zero datetime=True");
            conn.Open();

            string query = "SELECT * FROM pasien";
            using (MySqlDataAdapter da = new MySqlDataAdapter(query, conn))
            {
                using (DataTable dt = new DataTable())
                {
                    dt.Clear();
                    da.Fill(dt);
                    dataGridViewPasien.DataSource = dt;
                }
            }
        }
        public void display_data_berobat()
        {
            MySqlConnection conn = new MySqlConnection("server = localhost; database = app_pencatatan; uid = root; sslMode = none; password = ; convert zero datetime=True");
            conn.Open();

            string query = "SELECT * FROM berobat";
            using (MySqlDataAdapter da = new MySqlDataAdapter(query, conn))
            {
                using (DataTable dt = new DataTable())
                {
                    dt.Clear();
                    da.Fill(dt);
                    dataGridViewBerobat.DataSource = dt;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void FormTable_Load(object sender, EventArgs e)
        {
            display_data_pasien();
            display_data_berobat();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FormPasien frmpasien = new FormPasien();
            frmpasien.Show();
            this.Hide();
        }

       
    }
}
