﻿namespace APLIKASI_PENDAFTARAN_PASIEN
{
    partial class FormTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewPasien = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nm_pasien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.no_identitas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tggl_lahir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tmpt_lahir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.alamat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jenis_kelamin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridViewBerobat = new System.Windows.Forms.DataGridView();
            this.id_berobat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tggl_daftar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.no_pasien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nama_pasien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.no_telp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keluhan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.poli = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPasien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBerobat)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewPasien
            // 
            this.dataGridViewPasien.AllowUserToAddRows = false;
            this.dataGridViewPasien.AllowUserToDeleteRows = false;
            this.dataGridViewPasien.AllowUserToOrderColumns = true;
            this.dataGridViewPasien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPasien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.nm_pasien,
            this.no_identitas,
            this.tggl_lahir,
            this.tmpt_lahir,
            this.alamat,
            this.jenis_kelamin});
            this.dataGridViewPasien.Location = new System.Drawing.Point(12, 73);
            this.dataGridViewPasien.Name = "dataGridViewPasien";
            this.dataGridViewPasien.ReadOnly = true;
            this.dataGridViewPasien.Size = new System.Drawing.Size(528, 223);
            this.dataGridViewPasien.TabIndex = 4;
            this.dataGridViewPasien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "ID";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // nm_pasien
            // 
            this.nm_pasien.DataPropertyName = "nm_pasien";
            this.nm_pasien.HeaderText = "Nama Pasien";
            this.nm_pasien.Name = "nm_pasien";
            this.nm_pasien.ReadOnly = true;
            // 
            // no_identitas
            // 
            this.no_identitas.DataPropertyName = "no_identitas";
            this.no_identitas.HeaderText = "No Identitas";
            this.no_identitas.Name = "no_identitas";
            this.no_identitas.ReadOnly = true;
            // 
            // tggl_lahir
            // 
            this.tggl_lahir.DataPropertyName = "tggl_lahir";
            this.tggl_lahir.HeaderText = "Tanggal Lahir";
            this.tggl_lahir.Name = "tggl_lahir";
            this.tggl_lahir.ReadOnly = true;
            // 
            // tmpt_lahir
            // 
            this.tmpt_lahir.DataPropertyName = "tmpt_lahir";
            this.tmpt_lahir.HeaderText = "Tempat Lahir";
            this.tmpt_lahir.Name = "tmpt_lahir";
            this.tmpt_lahir.ReadOnly = true;
            // 
            // alamat
            // 
            this.alamat.DataPropertyName = "alamat";
            this.alamat.HeaderText = "alamat";
            this.alamat.Name = "alamat";
            this.alamat.ReadOnly = true;
            // 
            // jenis_kelamin
            // 
            this.jenis_kelamin.DataPropertyName = "jenis_kelamin";
            this.jenis_kelamin.HeaderText = "Jenis Kelamin";
            this.jenis_kelamin.Name = "jenis_kelamin";
            this.jenis_kelamin.ReadOnly = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "PASIEN";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 363);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "BEROBAT";
            // 
            // dataGridViewBerobat
            // 
            this.dataGridViewBerobat.AllowUserToAddRows = false;
            this.dataGridViewBerobat.AllowUserToDeleteRows = false;
            this.dataGridViewBerobat.AllowUserToOrderColumns = true;
            this.dataGridViewBerobat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBerobat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_berobat,
            this.tggl_daftar,
            this.no_pasien,
            this.nama_pasien,
            this.no_telp,
            this.keluhan,
            this.poli});
            this.dataGridViewBerobat.Location = new System.Drawing.Point(12, 382);
            this.dataGridViewBerobat.Name = "dataGridViewBerobat";
            this.dataGridViewBerobat.ReadOnly = true;
            this.dataGridViewBerobat.Size = new System.Drawing.Size(528, 223);
            this.dataGridViewBerobat.TabIndex = 6;
            this.dataGridViewBerobat.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // id_berobat
            // 
            this.id_berobat.DataPropertyName = "id";
            this.id_berobat.HeaderText = "ID";
            this.id_berobat.Name = "id_berobat";
            this.id_berobat.ReadOnly = true;
            // 
            // tggl_daftar
            // 
            this.tggl_daftar.DataPropertyName = "tggl_daftar";
            this.tggl_daftar.HeaderText = "Tanggal Daftar";
            this.tggl_daftar.Name = "tggl_daftar";
            this.tggl_daftar.ReadOnly = true;
            // 
            // no_pasien
            // 
            this.no_pasien.DataPropertyName = "no_pasien";
            this.no_pasien.HeaderText = "No Pasien";
            this.no_pasien.Name = "no_pasien";
            this.no_pasien.ReadOnly = true;
            // 
            // nama_pasien
            // 
            this.nama_pasien.DataPropertyName = "nm_pasien";
            this.nama_pasien.HeaderText = "Nama Pasien";
            this.nama_pasien.Name = "nama_pasien";
            this.nama_pasien.ReadOnly = true;
            // 
            // no_telp
            // 
            this.no_telp.DataPropertyName = "no_telp";
            this.no_telp.HeaderText = "No Telepon";
            this.no_telp.Name = "no_telp";
            this.no_telp.ReadOnly = true;
            // 
            // keluhan
            // 
            this.keluhan.DataPropertyName = "keluhan";
            this.keluhan.HeaderText = "Keluhan";
            this.keluhan.Name = "keluhan";
            this.keluhan.ReadOnly = true;
            // 
            // poli
            // 
            this.poli.DataPropertyName = "poli";
            this.poli.HeaderText = "Poli";
            this.poli.Name = "poli";
            this.poli.ReadOnly = true;
            // 
            // FormTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 650);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridViewBerobat);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridViewPasien);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormTable";
            this.Text = "FormTable";
            this.Load += new System.EventHandler(this.FormTable_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPasien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBerobat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridViewPasien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridViewBerobat;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn nm_pasien;
        private System.Windows.Forms.DataGridViewTextBoxColumn no_identitas;
        private System.Windows.Forms.DataGridViewTextBoxColumn tggl_lahir;
        private System.Windows.Forms.DataGridViewTextBoxColumn tmpt_lahir;
        private System.Windows.Forms.DataGridViewTextBoxColumn alamat;
        private System.Windows.Forms.DataGridViewTextBoxColumn jenis_kelamin;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_berobat;
        private System.Windows.Forms.DataGridViewTextBoxColumn tggl_daftar;
        private System.Windows.Forms.DataGridViewTextBoxColumn no_pasien;
        private System.Windows.Forms.DataGridViewTextBoxColumn nama_pasien;
        private System.Windows.Forms.DataGridViewTextBoxColumn no_telp;
        private System.Windows.Forms.DataGridViewTextBoxColumn keluhan;
        private System.Windows.Forms.DataGridViewTextBoxColumn poli;
    }
}