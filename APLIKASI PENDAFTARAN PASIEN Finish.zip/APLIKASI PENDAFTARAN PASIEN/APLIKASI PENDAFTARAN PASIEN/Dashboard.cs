﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APLIKASI_PENDAFTARAN_PASIEN
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FormPasien frmpasien = new FormPasien();
            frmpasien.TopLevel = false;
            frmpasien.AutoScroll = true;
            this.PanelContent.Controls.Clear();
            this.PanelContent.Controls.Add(frmpasien);
            frmpasien.Show();
            
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            FormBerobat frmberobat = new FormBerobat();
            frmberobat.TopLevel = false;
            frmberobat.AutoScroll = true;
            this.PanelContent.Controls.Clear();
            this.PanelContent.Controls.Add(frmberobat);
            frmberobat.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            FormHome frmHome = new FormHome();
            frmHome.TopLevel = false;
            frmHome.AutoScroll = true;
            this.PanelContent.Controls.Clear();
            this.PanelContent.Controls.Add(frmHome);
            frmHome.Show();

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            FormTable frmtable = new FormTable();
            frmtable.TopLevel = false;
            frmtable.AutoScroll = true;
            this.PanelContent.Controls.Clear();
            this.PanelContent.Controls.Add(frmtable);
            frmtable.Show();
        }
    }
}
