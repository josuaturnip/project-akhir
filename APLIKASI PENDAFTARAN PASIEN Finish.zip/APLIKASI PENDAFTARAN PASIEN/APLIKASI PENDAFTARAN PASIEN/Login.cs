﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APLIKASI_PENDAFTARAN_PASIEN
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = txtusername.Text;
            pass = txtpassword.Text;

            if (user == "admin" && pass == "admin")
            {
                MessageBox.Show("Anda Berhasil Login! " + "Selamat Datang " + user);
                Dashboard f2 = new Dashboard();
                f2.Show();
                this.Hide();
            }
            else MessageBox.Show("Input Yang Anda Masukkan Salah");

            

           
        }
    }
}
