﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace APLIKASI_PENDAFTARAN_PASIEN
{
    internal class Pasien:Connection
    {
       static MySqlConnection conn;
       static MySqlCommand cmd;

        public String id { get; set; }
        public String nama { get; set; }
        public String no_identitas { get; set; }
        public String tmpt_lahir { get; set; }
        public String tggl_lahir { get; set; }
        public String jenis_kelamin { get; set; }
        public String no_telp { get; set; }
        public String alamat { get; set; }

        public Pasien()
        {
            conn = new MySqlConnection(conString);
            cmd = new MySqlCommand();
        }

        public String Insert()
        {
            String error = null;
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO pasien (id,nm_pasien,no_identitas,tggl_lahir,tmpt_lahir,alamat,no_telp,jenis_kelamin) " +
                "VALUES (@id,@nm_pasien,@no_identitas,@tggl_lahir,@tmpt_lahir,@alamat,@no_telp,@jenis_kelamin)";
            cmd.Parameters.AddWithValue("@id", this.id);
            cmd.Parameters.AddWithValue("@nm_pasien", this.nama);
            cmd.Parameters.AddWithValue("@no_identitas", this.no_identitas);
            cmd.Parameters.AddWithValue("@tggl_lahir", this.tggl_lahir);
            cmd.Parameters.AddWithValue("@tmpt_lahir", this.tmpt_lahir);
            cmd.Parameters.AddWithValue("@alamat", this.alamat);
            cmd.Parameters.AddWithValue("@no_telp", this.no_telp);
            cmd.Parameters.AddWithValue("@jenis_kelamin", this.jenis_kelamin);


            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                error = e.Message;
            }
            return error;
        }

    }
}
