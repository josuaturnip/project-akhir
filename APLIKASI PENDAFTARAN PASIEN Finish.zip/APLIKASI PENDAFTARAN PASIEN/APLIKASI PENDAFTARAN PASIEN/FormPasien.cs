﻿using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;
using System.Drawing.Imaging;
using System.Globalization;

namespace APLIKASI_PENDAFTARAN_PASIEN
{
    public partial class FormPasien : Form
    {
        ArrayList pasienlist = new ArrayList();
        System.Collections.ArrayList DaftarPasien = new ArrayList();


        public FormPasien()
        {
            InitializeComponent();
            
        }

        public void clear()
        {
            textBoxNama.Text = "";
            textBoxNoIdent.Text = "";
            textBoxAlamat.Text = "";
            textBoxId.Text = "";
            dateTimePickerPasien.Value = DateTime.Now;
            textBoxTelp.Text = "";
            radioButtonMale.Checked = false;
            radioButtonFemale.Checked = false;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pasien pasien = new Pasien();
            pasien.id = textBoxId.Text;
            pasien.nama = textBoxNama.Text;
            pasien.no_identitas = textBoxNoIdent.Text;
            pasien.tggl_lahir = dateTimePickerPasien.Value.ToString("yyyy-MM-dd");
            pasien.tmpt_lahir = textBoxTmpt.Text;
            pasien.no_telp = textBoxTelp.Text;
            pasien.alamat = textBoxAlamat.Text;
            if (radioButtonMale.Checked == true)
            {
                pasien.jenis_kelamin = radioButtonMale.Text;
            }
            else pasien.jenis_kelamin = radioButtonFemale.Text;

            DaftarPasien.Add(pasien);
            DataTable dataTable = new DataTable();
            /*datagrid.DataSource = null;
            dataGridViewPegawai.DataSource = DaftarPegawai;*/
            



            String response;
            response = pasien.Insert();
            if (response == null)
            {
                
                MessageBox.Show("Insert Data Berhasil");
                clear();

            }
            else if (response != null)
                MessageBox.Show("Insert Data Gagal " + response);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
